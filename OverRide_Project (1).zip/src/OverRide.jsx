import { useState, useEffect, useRef } from "react";

export default function OverRide() {
  const [license, setLicense] = useState("");
  const [accessGranted, setAccessGranted] = useState(false);
  const [bgTime, setBgTime] = useState("day");
  const [steeringAngle, setSteeringAngle] = useState(0);
  const steeringRef = useRef(null);

  const SECRET_CODE = "18071313";

  useEffect(() => {
    const hour = new Date().getHours();
    if (hour < 6 || hour >= 20) setBgTime("night");
    else if (hour >= 17) setBgTime("evening");
    else setBgTime("day");
  }, []);

  const handleSteering = (e) => {
    const rect = steeringRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const deltaX = e.clientX - centerX;
    setSteeringAngle(Math.max(-90, Math.min(90, deltaX / 2)));
  };

  const bgColors = {
    day: "bg-blue-200",
    evening: "bg-orange-300",
    night: "bg-gray-800",
  };

  return (
    <div className={`min-h-screen ${bgColors[bgTime]} flex items-center justify-center p-4`}>
      {!accessGranted ? (
        <div className="bg-white p-6 rounded-2xl shadow-xl w-full max-w-sm text-center">
          <h1 className="text-2xl font-bold mb-4">הכנס מספר רכב</h1>
          <input
            type="text"
            className="border rounded px-3 py-2 w-full text-center text-lg"
            value={license}
            onChange={(e) => setLicense(e.target.value)}
          />
          <button
            className="mt-4 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
            onClick={() => setAccessGranted(license === SECRET_CODE)}
          >
            כניסה
          </button>
          {license && license !== SECRET_CODE && (
            <p className="text-red-500 mt-2">מספר שגוי</p>
          )}
        </div>
      ) : (
        <div className="w-full max-w-md text-center">
          <h2 className="text-xl font-semibold mb-4">סימולטור נהיגה</h2>
          <div
            ref={steeringRef}
            onMouseMove={handleSteering}
            onTouchMove={(e) => handleSteering(e.touches[0])}
            className="mx-auto mb-6 w-40 h-40 rounded-full bg-gray-600 flex items-center justify-center shadow-inner"
            style={{ transform: `rotate(${steeringAngle}deg)` }}
          >
            <span className="text-white font-bold">הגה</span>
          </div>
          <div className="flex justify-around">
            <button className="bg-green-500 text-white px-6 py-3 rounded-full text-lg active:scale-95">גז</button>
            <button className="bg-red-500 text-white px-6 py-3 rounded-full text-lg active:scale-95">בלם</button>
          </div>
        </div>
      )}
    </div>
  );
}